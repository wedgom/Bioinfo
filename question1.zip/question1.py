#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os
from gi.repository import Gtk

class Bioinfo(Gtk.Window):
	#Function to call GUI
	def __init__(self):
		builder = Gtk.Builder()
		builder.add_from_file(os.getcwd() + "/gui.glade")
		window = builder.get_object("window1")
		window.set_title("Simple Convert")
		
		#Build to interface
		window.show()
		
		#Values Initial
		self.dna = builder.get_object("DNA_entry")
		self.rna = builder.get_object("RNA_entry")
		
		#Signals
		builder.connect_signals({"on_convertButton_clicked":self.dna_rna
			}) 
		
	def dna_rna(self, widget):
	#Converting a DNA sequence to mRNA
		dna_seq = self.dna.get_text()
		dna_seq = dna_seq.upper()
		rna_seq = dna_seq.replace('T','U')
		self.rna.set_text(rna_seq)
		
if __name__ == "__main__":
	app = Bioinfo()
	Gtk.main()
		
		
