#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os
from gi.repository import Gtk

class Bioinfo(Gtk.Window):
	#Function to call GUI
	def __init__(self):
		builder = Gtk.Builder()
		builder.add_from_file(os.getcwd() + "/gui2.glade")
		window = builder.get_object("window1")
		window.set_title("GC Convert")
		
		#Build to interface
		window.show()
		
		#Values Initial
		self.seq = builder.get_object("seq_entry")
		self.result = builder.get_object("result_label")
		
		#Signals
		builder.connect_signals({"on_calculator_button_clicked":self.gc_calc,
								 "on_clean_button_clicked":self.gc_clean
			}) 
	# Calculate the G+C percentage content of a DNA sequence
	def gc_calc(self, widget):
		dna_seq = self.seq.get_text()
		dna_seq = dna_seq.upper()
		g_count = dna_seq.count('G')
		c_count = dna_seq.count('C')
		length = len(dna_seq)
		gc_count = g_count + c_count
		gc_content = 100.0*gc_count / length
		self.result.set_text("CG: %.2f" % gc_content + "%")
	
	def gc_clean(self, widget):
		self.seq.set_text('')
		self.result.set_text("GC%:")


if __name__ == "__main__":
	app = Bioinfo()
	Gtk.main()
